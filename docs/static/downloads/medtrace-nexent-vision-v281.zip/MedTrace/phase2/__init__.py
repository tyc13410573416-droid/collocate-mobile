"""Stage-two integration package."""
